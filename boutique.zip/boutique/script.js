/* ==============================
   NOOL CITADEL — JavaScript
   ============================== */

document.addEventListener('DOMContentLoaded', () => {

    // ── Mobile Navigation ──
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    let overlay = document.createElement('div');
    overlay.classList.add('nav__overlay');
    document.body.appendChild(overlay);

    function toggleMenu() {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
    }

    navToggle.addEventListener('click', toggleMenu);
    overlay.addEventListener('click', toggleMenu);

    // Close menu on link click
    document.querySelectorAll('.nav__link').forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu.classList.contains('active')) toggleMenu();
        });
    });

    // ── Sticky Header Shadow ──
    const header = document.getElementById('header');
    window.addEventListener('scroll', () => {
        header.classList.toggle('scrolled', window.scrollY > 50);
    });

    // ── Back to Top Button ──
    const backToTop = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
        backToTop.classList.toggle('visible', window.scrollY > 500);
    });

    backToTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // ── Scroll Reveal Animations ──
    const revealElements = document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right');

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                revealObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.15,
        rootMargin: '0px 0px -40px 0px'
    });

    revealElements.forEach(el => revealObserver.observe(el));

    // ── Product Filter ──
    const filterBtns = document.querySelectorAll('.filter-btn');
    const productCards = document.querySelectorAll('.product-card');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active button
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.dataset.filter;

            productCards.forEach((card, index) => {
                const category = card.dataset.category;
                const show = filter === 'all' || category === filter;

                if (show) {
                    card.classList.remove('hidden');
                    card.style.animation = `fadeInUp 0.5s ease ${index * 0.05}s both`;
                } else {
                    card.classList.add('hidden');
                    card.style.animation = '';
                }
            });
        });
    });

    // ── Add to Cart Toast ──
    const toast = document.getElementById('toast');
    const cartBtns = document.querySelectorAll('.btn--cart');
    const cartBadges = document.querySelectorAll('.action-badge');
    let cartCount = 0;

    function showToast(message = 'Item added to cart!') {
        toast.querySelector('span').textContent = message;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2500);
    }

    cartBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            cartCount++;
            // Update all cart badges (last action badge is cart)
            const badges = document.querySelectorAll('.action-badge');
            if (badges.length >= 2) {
                badges[badges.length - 1].textContent = cartCount;
            }

            // Button animation
            btn.textContent = 'Added ✓';
            btn.style.background = '#4caf50';
            btn.style.borderColor = '#4caf50';

            setTimeout(() => {
                btn.textContent = 'Add to Cart';
                btn.style.background = '';
                btn.style.borderColor = '';
            }, 1500);

            showToast();
        });
    });

    // ── Wishlist Toggle ──
    document.querySelectorAll('.product-action').forEach(btn => {
        if (btn.querySelector('.fa-heart')) {
            btn.addEventListener('click', () => {
                const icon = btn.querySelector('i');
                icon.classList.toggle('far');
                icon.classList.toggle('fas');

                if (icon.classList.contains('fas')) {
                    icon.style.color = '#e74c3c';
                    // Update wishlist badge
                    const badges = document.querySelectorAll('.action-badge');
                    if (badges.length >= 2) {
                        let count = parseInt(badges[0].textContent) || 0;
                        badges[0].textContent = count + 1;
                    }
                } else {
                    icon.style.color = '';
                    const badges = document.querySelectorAll('.action-badge');
                    if (badges.length >= 2) {
                        let count = parseInt(badges[0].textContent) || 0;
                        badges[0].textContent = Math.max(0, count - 1);
                    }
                }
            });
        }
    });

    // ── Hero Slider Dots ──
    const dots = document.querySelectorAll('.hero__dots .dot');
    const heroImages = [
        
        'images/hacksound2.jpeg',
        'images/hacksound5.jpeg',
        'images/hacksound19.jpg'

    ];

    let currentSlide = 0;
    const heroImg = document.querySelector('.hero__image img');

    function changeSlide(index) {
        currentSlide = index;
        dots.forEach(d => d.classList.remove('active'));
        dots[index].classList.add('active');
        heroImg.style.opacity = '0';
        setTimeout(() => {
            heroImg.src = heroImages[index];
            heroImg.style.opacity = '1';
        }, 300);
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => changeSlide(index));
    });

    // Auto-advance slider
    setInterval(() => {
        currentSlide = (currentSlide + 1) % heroImages.length;
        changeSlide(currentSlide);
    }, 5000);

    // ── Hero image smooth transition ──
    if (heroImg) {
        heroImg.style.transition = 'opacity 0.4s ease';
    }

    // ── Contact Form Submission ──
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            showToast('Message sent successfully!');
            contactForm.reset();
        });
    }

    // ── Newsletter Form ──
    const newsletterForm = document.getElementById('newsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            showToast('Subscribed! Welcome to Nool Citadel ✨');
            newsletterForm.reset();
        });
    }

    // ── Smooth Scroll for Anchor Links ──
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const target = document.querySelector(targetId);
            if (target) {
                e.preventDefault();
                const headerHeight = header.offsetHeight;
                const targetPosition = target.getBoundingClientRect().top + window.scrollY - headerHeight - 20;
                window.scrollTo({ top: targetPosition, behavior: 'smooth' });
            }
        });
    });

    // ── Parallax Effect on Scroll ──
    const parallaxBanner = document.querySelector('.parallax-banner');
    if (parallaxBanner && window.innerWidth > 768) {
        window.addEventListener('scroll', () => {
            const scrolled = window.scrollY;
            const bannerTop = parallaxBanner.offsetTop;
            const speed = 0.3;

            if (scrolled > bannerTop - window.innerHeight && scrolled < bannerTop + parallaxBanner.offsetHeight) {
                const yPos = (scrolled - bannerTop + window.innerHeight) * speed;
                parallaxBanner.style.backgroundPositionY = `${yPos}px`;
            }
        });
    }

    // ── Fade-in animation keyframes (inject via JS) ──
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
    `;
    document.head.appendChild(style);

});
